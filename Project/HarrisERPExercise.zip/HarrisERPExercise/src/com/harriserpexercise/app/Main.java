package com.harriserpexercise.app;


public class Main {

	public static void main(String[] args) {				
		ConsoleRunner runner = new ConsoleRunner();
		runner.Run();				
	}

}
